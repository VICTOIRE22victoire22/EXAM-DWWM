<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

final class HomeController extends AbstractController
{
    #[Route('/home', name: 'app_home')]
    public function index(): Response
    {
        return $this->render('home/index.html.twig', [
            'controller_name' => 'HomeController',
        ]);
    }

    #[Route('/expo', name: 'app_expo')]
    public function exposition(): Response
    {
        return $this->render('home/expo.html.twig');
    }

    #[Route('/category', name: 'app_category')]
    public function categories(): Response
    {
        return $this->render('home/category.html.twig');
    }

    #[Route('/comment', name: 'app_comment')]
    public function commentaires(): Response
    {
        return $this->render('home/comment.html.twig');
    }
}
