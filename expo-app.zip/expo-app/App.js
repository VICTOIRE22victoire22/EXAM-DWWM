// App.js
import React from 'react';
import { View, Text } from 'react-native';
import './dist/styles.css'; // CSS généré par Tailwind

export default function App() {
  return (
    <View className="flex-1 justify-center items-center bg-blue-500">
      <Text className="text-white text-lg">Hello Tailwind!</Text>
    </View>
  );
}
